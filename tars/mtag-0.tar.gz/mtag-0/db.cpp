//
// C++ Implementation: db
//
// Description: 
//
//
// Author: Felix Bechstein <f@ub0r.de>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif


#include <stdlib.h>

/* For taglib */
#include <fileref.h>
#include <tag.h>

using namespace std;
